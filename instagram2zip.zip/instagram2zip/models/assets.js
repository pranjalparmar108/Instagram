/*eslint-disable*/
"use strict";
const { Model } = require("sequelize");
const utils = require("../utils/generateUUId")
module.exports = (sequelize, DataTypes) => {
  class assets extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  assets.init(
    {
      Id: {
        type: DataTypes.STRING(15),
        allowNull: false,
        defaultValue: () => {
          const randomId = utils.generateUUI();
          return randomId;
        },
        primaryKey: true,
      },
     
      type: DataTypes.STRING,
      name: DataTypes.STRING,
      serialCode: DataTypes.STRING,
      model: DataTypes.STRING,
      userId: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "assets",
      timestamps: true
    }
  );
  return assets;
};
