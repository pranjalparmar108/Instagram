/*eslint-disable*/
"use strict";
const { Model } = require("sequelize");
const utils = require("../utils/generateUUId")
module.exports = (sequelize, DataTypes) => {
  class accounts extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  accounts.init(
    {
      Id: {
        type: DataTypes.STRING(15),
        allowNull: false,
        defaultValue: () => {
          const randomId = utils.generateUUI();
          return randomId;
        },
        primaryKey: true,
      },
     
      accountNumber: DataTypes.STRING,
      userId: DataTypes.STRING,
      IFSCcode: DataTypes.STRING,
      bankName: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "accounts",
      timestamps: true
    }
  );
  return accounts;
};
