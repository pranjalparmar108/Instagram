'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('users', {
      Id: { type: Sequelize.STRING(15), allowNull: false, primaryKey: true },
      firstName: { type: Sequelize.STRING(30), allowNull: false },
      lastName: { type: Sequelize.STRING(30), allowNull: false },
      password: { type: Sequelize.STRING(30), allowNull: false },
      emailAddress: { type: Sequelize.STRING(30), allowNull: false },
      mobilePhone: { type: Sequelize.STRING(100), allowNull: false },
      role:{ type: Sequelize.STRING(30), allowNull: false },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('users');
  }
};
