'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('accounts', {
      Id: { type: Sequelize.STRING(15), allowNull: false, primaryKey: true },
      accountNumber: { type: Sequelize.STRING(30), allowNull: false },
      userId: { type: Sequelize.STRING(30), allowNull: false },
      IFSCcode: { type: Sequelize.STRING(30), allowNull: false },
      bankName: { type: Sequelize.STRING(30), allowNull: false },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('accounts');
  }
};
