const e = require('express');
const db = require('../models');
const {resServerError,resFound,resErrorOccured} = require("../utils/response")




const getAllassets = async(req,res)=>{
    try {
        const assets = await db.assets.findAll({

        })
        return resFound(res,assets)
        
    } catch (error) {
        return resErrorOccured(res,error)
        
    }
}

const createAssets = async(req,res)=>{
try {
    let {type,name,serialCode,model,userId} = req.body
    const assets = await db.assets.create({
        type,
        name,
        serialCode,
        model,
        userId
    })
    return resFound(res,assets)
    
} catch (error) {
    return resErrorOccured(res,error)
}
}

const getassetsbyUserid = async(req,res)=>{
try {
    let Id = req.query.id
    console.log("idmmmmmmmmm",Id)
    const assets = await db.users.findOne({
        where:{
           Id:Id
        },
        include:[
              {
                model: db.assets,
                as: 'userAssets',
                
              }
        ]
    })
    return resFound(res,assets)
    
}  catch (error) {
    console.error("Error fetching assets by user ID:", error);  // Log the error for debugging
    return resErrorOccured(res, error);
  }

}



module.exports = {
    getAllassets,
    createAssets,
    getassetsbyUserid
}