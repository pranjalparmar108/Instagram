const db = require('../models');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const XLSX = require('xlsx');
const multer = require('multer');
const fs = require('fs');
const path = require('path');


const nodemailer = require('nodemailer');
const {users}= require('../models'); // Assuming you have your Sequelize model defined in a separate file
const {resServerError,resFound,resErrorOccured} = require("../utils/response")
const {Parser} = require('json2csv')

const postUserSignup = async (req, res) => {
  const { emailAddress, password,role,firstName } = req.body;
  try {
    const existingUser = await users.findOne({ where: { emailAddress } });

    if (existingUser) {
      return res.status(203).json({ message: 'User already exists' });
    }

    // const hashedPassword = await bcrypt.hash(password, 10);
    // const hashedPassword = await bcrypt.hash(password, 10);
// console.log("Hashed password during signup:", hashedPassword);

    const newUser = await users.create({ emailAddress, password: password,role,firstName});

    // Generate token
    const token = jwt.sign({ emailAddress: newUser.emailAddress, userId: newUser.Id }, 'pranjal', { expiresIn: '1h' });

    res.status(201).json({ message: 'User created successfully', user: newUser, token: token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

const postUserLogin = async (req, res) => {
  const { emailAddress, password, rememberMe } = req.body;

  try {
    const userdata = await users.findOne({ where: { emailAddress } });
    console.log("userdata", userdata);

    if (userdata) {
      if (userdata.password === password) {
        const tokenExpiry = rememberMe ? '7d' : '1h'; 
        console.log(userdata.role)
        const token = jwt.sign({ emailAddress: userdata.emailAddress,role: userdata.role }, 'pranjal', { expiresIn: tokenExpiry });

        const transporter = nodemailer.createTransport({
          host: 'smtp.ethereal.email',
          port: 587,
          auth: {
            user: 'cody87@ethereal.email',
            pass: 'Xcv5xxdNttM1cMQ1Kn'
          }
        });

        const mailOptions = {
          from: 'noreply@gmail.com',
          to: userdata.emailAddress,
          subject: 'Login Successful',
          text: 'Hello, you have successfully logged in.'
        };

        transporter.sendMail(mailOptions, (error, info) => {
          if (error) {
            console.error('Error sending email:', error);
            res.status(500).json({ message: 'Error sending email' });
          } else {
            console.log('Email sent:', info.response);
            res.status(200).json({ message: 'Login successful', user: userdata, token: token });
          }
        });
      } else {
        res.status(401).json({ message: 'Invalid credentials' });
      }
    } else {
      res.status(401).json({ message: 'Invalid credentials' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
};


const getAlluser = async(req,res)=>{
  try {
    const users = await db.users.findAll({
    })
    return resFound(res,users)
  } catch (error) {
    return resErrorOccured(res,error)
    
  }
}

const createExcelFile = async (data) => {
  try {
    console.log("data",data)
      let workSheet = XLSX.utils.json_to_sheet(data);
      const workBook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workBook, workSheet, "Sheet1");
      const buffer = XLSX.write(workBook, { bookType: 'xlsx', type: 'buffer' });
      return buffer;
  } catch (error) {
      throw error;
  }
};

const exportUsersToExcel = async (req, res) => {
  try {
      const users = await db.users.findAll();
      console.log("users",users)
      const cleanUsers = users.map(user => user.dataValues);
      const buffer = await createExcelFile(cleanUsers);
      console.log("buffer",buffer)
      res.setHeader('Content-Disposition', 'attachment; filename=users.xlsx');
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.send(buffer);
  } catch (error) {
      console.error('Error exporting users to Excel:', error);
      res.status(500).json({ error: 'An error occurred while exporting users' });
  }
};
const exportCsv =  async (req, res) => { 
  const userdata = await db.users.findAll()
  const data = userdata.map(user => user.get({ plain: true }));
  const json2csvParser = new Parser();
  const csv = json2csvParser.parse(data);
  const filePath = path.join(__dirname, '../uploads/data.csv');
 
  fs.writeFile(filePath, csv, (err) => {
      if (err) {
          return res.status(500).json({ error: 'Failed to save CSV file' });
      }
 
      res.setHeader('Content-Disposition', 'attachment; filename=data.csv');
      res.setHeader('Content-Type', 'text/csv');
      res.sendFile(filePath);
  });
}
const storage = multer.diskStorage({
  destination: './uploads/',
  filename: (req, file, cb) => {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  }
});


const upload = multer({ storage: storage });

const uploadDocument = async (req, res) => {
  try {
    // let Id = req.query.Id;
    if (!req.file) {
      return res.status(400).json({ error: 'File not found' });
    }
    console.log(req.file);
    let requestBody = {
      // Id,
      size: req.file.size,
      fileName: req.file.filename,
      filePath: req.file.path, 
      comments: req.body.comments || "Uploaded",
    };
    res.status(200).json({
      message: 'File uploaded successfully',
      requestBody: requestBody
    });

  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'An error occurred while uploading the document' });
  }
};




module.exports = {
  postUserSignup,
  postUserLogin,
  uploadDocument,
  getAlluser,
  createExcelFile,
  exportUsersToExcel,
  exportCsv

};
