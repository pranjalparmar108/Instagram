const db = require('../models');
const {resServerError,resFound,resErrorOccured} = require("../utils/response")

 const getaccountByuserId = async(req,res)=>{
try {
    let Id = req.query.id
    const accounts = await db.accounts.findOne({
   where:{
    userId:Id
   },
   include:[
          {
            model: db.users,
            as: 'users',
            attributes: ["Id", "firstName", "emailAddress", "mobilePhone"]
          }
   ]
    })
    return resFound(res,accounts)
    
} catch (error) {
    return resServerError(res,error)
}
 }

 const getAllaccount = async(req,res)=>{
try {
 const account = await db.accounts.findAll({

 })
 return resFound(res,account)
    
} catch (error) {
    return resErrorOccured(res,error)
    
}
 }

 const postAccountdetails = async(req,res)=>{
    try {
        const { accountNumber, userId, IFSCcode, bankName } = req.body;
        const createAccount = await db.accounts.create({
            accountNumber,
            userId,
            IFSCcode,
            bankName
        })
        return resFound(res,createAccount)
        
    } catch (error) {
        return resErrorOccured(res,error)
        
    }
 }

module.exports = {
    getaccountByuserId,
    getAllaccount,
    postAccountdetails
}