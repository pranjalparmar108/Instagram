const routes = require('express').Router();
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const {verifyToken} = require("../middlewear/jwt")
const loginController = require('../controllers/login.controllers');
const {checkUserRole} = require("../middlewear/userRoleaccess")
const {Parser} = require('json2csv')

const storage = multer.diskStorage({
    destination: './uploads/',
    filename: (req, file, cb) => {
      cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname)); // File naming convention
    }
  });
const upload = multer({ storage: storage });



routes.post("/users",loginController.postUserSignup)
routes.post("/login",loginController.postUserLogin)
routes.get("",verifyToken, checkUserRole(['admin']),loginController.getAlluser)
routes.get("/exportUsersToExcel",loginController.exportUsersToExcel)
routes.post('/upload', upload.single('file'), loginController.uploadDocument);
routes.get("/exportCsv",loginController.exportCsv)


module.exports = routes;
