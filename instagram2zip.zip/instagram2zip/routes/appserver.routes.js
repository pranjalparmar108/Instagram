const Router = require('express');
const login = require('./login.routes');
const account = require('./account.routes');
const assets = require('./assets.routes')
const   routes = Router();
routes.use('/login', login);
routes.use('/account',account)
routes.use('/assets',assets)
module.exports = routes;
