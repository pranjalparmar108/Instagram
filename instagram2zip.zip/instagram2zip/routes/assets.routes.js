const routes = require('express').Router();
const assetsControllers = require("../controllers/assets.controllers");


routes.get("/assets",assetsControllers.getAllassets);
routes.post("/create/assets",assetsControllers.createAssets);
routes.get("/users/assets",assetsControllers.getassetsbyUserid)





module.exports = routes;