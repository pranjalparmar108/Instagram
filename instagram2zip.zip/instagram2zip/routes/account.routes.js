const routes = require('express').Router();
const accountControllers = require('../controllers/account.controllers')


routes.get("/accounts",accountControllers.getaccountByuserId)
routes.get("",accountControllers.getAllaccount)
routes.post("",accountControllers.postAccountdetails)

module.exports = routes;